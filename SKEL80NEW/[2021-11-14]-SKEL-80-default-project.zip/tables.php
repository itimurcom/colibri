
<?php
// ================ CRC ================
// version: 1.57.02
// hash: 9111055944fc3fbf9642774e16c5958b769d6549ae29942afd01aac822bfd213
// date: 05 June 2021 14:27
// ================ CRC ================
include ("engine/kernel.php");
check_skeleton_basic_tables();
?>