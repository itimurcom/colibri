var sliders=[];
var slides;

class Kenburns {
    constructor(element, options) {
        this.ok = ((this.slider = document.getElementById(element)) != null);
        if (this.ok) {
            this.duration = this.slider.getAttribute('kb-duration');
            console.log(this.duration);
            this.duration = this.duration ? this.duration : 10;
            this.speed = this.slider.getAttribute('kb-speed');
            this.speed = this.speed ? this.speed : 4;
            this.play = this.slider.getAttribute('kb-play');

            this.slides = this.slider.getElementsByClassName('kb-slide');
            this.idx = 0;
            this.max = this.slides.length - 1;
            
            if (this.b_next = this.slider.getElementsByClassName('kb-next')[0]) {
                this.b_next.style.cursor = 'pointer';
                this.b_next.onclick = () => {
                    clearInterval(this.interval);
                    this._interval();
                    this._next();
                    }
                }
            if (this.b_prev = this.slider.getElementsByClassName('kb-prev')[0]) {
                this.b_prev.style.cursor = 'pointer';
                this.b_prev.onclick = () => {
                    clearInterval(this.interval);
                    this._interval();
                    this._prev();
                    }
                }
            this._slide();
            this._interval();
        }
    }

    _interval() {
        this.interval = ((this.max > 0) && (this.play=='auto'))
                ? setInterval( () => {
                    this._next();
                    }, this.duration * .8 * 1000)
                : null;
        }

    _slide_off() {
        if (this.ok) {
            const slide = this.slides[this.idx];
            const bg = slide.querySelector('.kb-bg');

            slide.style.animationName = null;
            slide.offsetHeight;
            slide.style.animationName = 'slide_off';
            slide.style.animationDuration = (this.duration / 5) + 's';
            slide.style['animation-fill-mode'] = 'forwards';
            slide.style['pointer-events'] = 'none';
            }
        }

    _slide() {
        if (this.ok) {        
            const slide = this.slides[this.idx];
            const bg = slide.querySelector('.kb-bg');

            slide.style.animationName = null;
            slide.offsetHeight;
            slide.style.animationName = 'slide';
            slide.style.animationDuration = this.duration + 's';
            slide.style['animation-fill-mode'] = 'forwards';
            slide.style['pointer-events'] = 'auto';

            bg.style.animationName = null;
            bg.offsetHeight;
            bg.style.animationName = 'kenburns_s' + this.speed;
            bg.style.animationDuration = this.duration + 's';
            bg.style['animation-fill-mode'] = 'forwards';
            bg.style['animation-timing-function'] = 'ease-in-out';
            }
        }

        _next() {
            if (this.ok) {  
                this._slide_off();
                this.idx = (this.idx == this.max) ? 0 : (this.idx+1);
                this._slide();
                }
        }

        _prev() {
            if (this.ok) {  
                this._slide_off();
                this.idx = (this.idx == 0) ? this.max : (this.idx-1);
                this._slide();
                }
        }

}

function kenburns_events() {
    let sl_arr = document.getElementsByClassName('kb-slider');
    const sl_max = sl_arr.length - 1;
    sliders = [];
    for (let sl of sl_arr) {
        sliders.push(new Kenburns(sl.getAttribute('id')));
        }
    }

$(document).ready(function() {
    kenburns_events();
});

// ================ CRC ================
// version: 1.15.01
// hash: 1f1564fa5e2a726029d5ef952a16589d18bf2a49443126d9353d2963ce083625
// date: 16 September 2018 17:02
// ================ CRC ================
function itkenburns_state(element)
	{
	var data = $(element).attr('rel');
	if ($(element).attr('evented')!=1)

	$.ajax	({
		type: 'POST',
		url: '/ed_field.php',
		data:
			{
			op: 'itkenburnsstate',
			data: data,
			},

		beforeSend: function()
			{
			$(element).attr('evented',1);
			},

		success: function(msg)
			{
			try	{
				var obj = $.parseJSON(msg);
				}
				catch(e) {
					console.error('ERROR: '+ msg);
					}
				if (obj === null)
					{
					} else 
					if (obj['result']==1)
						{
						$(element).replaceWith($(obj['value']));
                        kenburns_events();
                        refine_events();
                        // set_modal_events();
                        }
		
			},
		complete : function ()
			{
			$(element).removeAttr('evented');
			},
		error:	function (request, error) {
			}
		});		
	}
	
function itkenburns_reload(element)
	{
	var data = $(element).attr('rel');
	if ($(element).attr('evented')!=1)

	$.ajax({
		type: 'POST',
		url: '/ed_field.php',
		data:
			{
			op: 'itkenburnsreload',
			data: data,
			},

		beforeSend: function() {
			$(element).attr('evented',1);
			},

		success: function(msg)
			{
			try	{
				var obj = $.parseJSON(msg);
				if (obj === null)
					{
					} else 
					if (obj['result']==1)
						{
						$(element).replaceWith($(obj['value']));
                        refine_events();
                        kenburns_events();
                        // set_modal_events();
						}
				}
				catch(e) {
					console.error('ERROR: '+ msg);
					}
			
			},
		complete : function ()
			{
			$(element).removeAttr('evented');
			},
		error:	function (request, error) {
			}
		});		
	}


function kb_easyng(key) {
    switch(key) {
        case 'ease-in-out' :
        case 'easeInOut' : { 
            return 'ease-in-out';
            break;
            }
        default : {
            return 'ease-in-out';
            break;
        }
    }
}