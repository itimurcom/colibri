modal_resize_interval = 1000;
$(document).ready(function () {

	 if(window.location.hash) {
		if ( window.location.hash ) {window.scroll(0,0); }
		setTimeout( function() { window.scroll(0,0); }, 1);
	
		setTimeout( function() { 
			$(window.location.hash).ScrollTo({duration:800, offsetTop:0, callback:function(){}});
			}, 600);
    }

	refine_events();
	console.log('ready');
}); // ready