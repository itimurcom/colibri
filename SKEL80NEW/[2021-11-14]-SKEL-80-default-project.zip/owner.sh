#!/bin/sh
chown -R www-root:www-root .