
<?=ready_val($_CONTENT['footer'])?>
<?=ready_val($_CONTENT['focus'])?>
</div>
<span id='goup' class='goup'></span>
</body>