<!DOCTYPE html>
<html lang='<?=CMS_LANG?>'>
<head>
	<?=ready_val($_CONTENT['header'])?>
</head>
<?
// $o_focus = new itFocus();
// $focus_msg = !is_null($o_focus->code) ? $o_focus->code : NULL
// unset($o_focus);
?>
<body>
<?include ('tpl.photoswipe.php'); ?>