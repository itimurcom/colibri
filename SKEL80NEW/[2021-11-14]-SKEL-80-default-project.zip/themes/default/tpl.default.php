
<?=ready_val($_CONTENT['menu'])?>
<?=ready_val($_CONTENT['content'])?>
