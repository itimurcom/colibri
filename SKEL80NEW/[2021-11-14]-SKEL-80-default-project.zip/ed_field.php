<?
include ("engine/kernel.php");
$path = UPLOADS_ROOT;

// распакуем данные - новый вид работы
$orig_REQUEST = $_REQUEST;
$data = itEditor::_redata();

if (isset($_SERVER['HTTP_REFERER']))
	{
	$url = $_SERVER['HTTP_REFERER'];
	} else $url = '/';

if (DEBUG_ON==1)
	{
	write_log("request:\n\n".print_r($_REQUEST,true), '--request.log');
	write_log("FILES:\n\n".print_r($_FILES,true), '--request.log');
	write_log("refered:\n\n".$url, '--request.log');
	}

// обработка для модератора
if ($_USER->is_logged())
	{
	if (isset($_REQUEST['op']))	{
		// сначала попробуем обработать галлерею поля
		if (itImages::events($url, $path)) return;
		// попробуем обработать события редактора
		if (itEditor::events($url, $path)) return;
		// попробуем обработать события редактируемых форм (2.1)
		if (itForm2::events($url, $path)) return;
		// попробуем обработать события слайдкра
		if (itKenburns::events($url, $path)) return;
		}
	}


// обработка без логина
if (isset($_REQUEST['op']))	{
	// попробуем обработать события загрузки изображений
	if (itUpGal::events($url, $path)) return;
	// попробуем обработать события редактора	
	if (itEditor::events($url, $path)) return;
	}
	
if (DEBUG_ON!=1) {
	cms_redirect_page("$url");	
	} else	{
		echo "<font color='lightgray'>_REQUEST:".print_rr($_REQUEST).
		"_FILES:\n\n".print_rr($_FILES).
		"_REFERRER:".$url."</font>";
		}
?>