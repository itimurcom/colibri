<?
$data = itEditor::_redata();
?>